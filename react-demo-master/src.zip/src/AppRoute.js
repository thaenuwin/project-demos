import React from 'react';
import {BrowserRouter,Switch,withRouter,Route,Link} from 'react-router-dom';
import * as route from './features/config/route.config'
import DemoContainer from './features/home/container/demoContainer';

const AppRoute=(props)=>{
    return(
        <BrowserRouter>
        <Switch>
            <Route path={route.demo} component={DemoContainer} />

            
        </Switch>
        </BrowserRouter>
    )
}

export default AppRoute;

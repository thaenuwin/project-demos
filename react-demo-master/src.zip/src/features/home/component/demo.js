import React from 'react';

const Demo=props=>{
    return(
        <div>
            <h1>Demo Pages</h1>
        </div>
    )
}
export default Demo;
import React from 'react';
import Demo from '../component/demo';


const DemoContainer=(props)=>{
    return(
        <Demo></Demo>
    )
}
export default DemoContainer;
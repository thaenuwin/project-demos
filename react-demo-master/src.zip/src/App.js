import React from 'react';
import logo from './logo.svg';
import './App.css';
import AppRoute from './AppRoute';


function App() {
  return (
    <div className="App">
      <header className="App-header">
        <AppRoute/>
      </header>
    </div>
  );
}

export default App;
